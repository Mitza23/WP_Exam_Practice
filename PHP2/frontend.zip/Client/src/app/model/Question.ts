export interface Question{
  id: number;
  text: string;
  correctAnswer: string;
  wrongAnswer: string;
}
